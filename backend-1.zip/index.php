<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
<h1>Welcome <?php echo $_POST["fname"]; ?> <?php echo $_POST["lname"]; ?></h1>
   <br>

    <?php echo $_POST["email"]; ?>
<br>

    
   
  
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
  </body>
</html>